package org.logstashplugins;

import co.elastic.logstash.api.Configuration;
import co.elastic.logstash.api.Context;
import co.elastic.logstash.api.Event;
import co.elastic.logstash.api.FilterMatchListener;
import org.junit.Assert;
import org.junit.Test;
import org.logstash.plugins.ConfigurationImpl;
import org.logstash.plugins.ContextImpl;

import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicInteger;

public class SequoiaClientExceptionFilterTest {

    private static String body = "ThreadIdentity: RSVZINASTI\\SYS_400D_DOM_WOR"
    + "\n" + "ClaimsPrincipal: RSVZINASTI\\SYS_400D_DOM_WOR"
    + "\n" + "UserName: SYS_400D_DOM_WOR"
    + "\n"
    + "\n" + "FeatureToggles"
    + "\n" + "toggle 1234" 
    + "\n"
    + "\n" + "MessageId: e1910232-a276-835e-e053-2011660a4107"
    + "\n"
    + "\n" + "1) System.IO.FileLoadException"
    + "\n" + "Message: Could not load file or assembly 'System.Memory, Version=4.0.1.1, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51' or one of its dependencies. The located assembly's manifest definition does not match the assembly reference. (Exception from HRESULT: 0x80131040)"
    + "\n" + "FileName: System.Memory, Version=4.0.1.1, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51"
    + "\n" + "FusionLog: WRN: Assembly binding logging is turned OFF."
    + "\n" + "To enable assembly bind failure logging, set the registry value [HKLM\\Software\\Microsoft\\Fusion!EnableLog] (DWORD) to 1."
    + "\n" + "Note: There is some performance penalty associated with assembly bind failure logging."
    + "\n" + "To turn this feature off, remove the registry value [HKLM\\Software\\Microsoft\\Fusion!EnableLog]."
    + "\n"
    + "\n" + "HResult: 80131040"
    + "\n"
    + "\n" + "StackTrace"
    + "\n" + "   at System.Diagnostics.ActivityTraceId.CreateRandom()"
    + "\n" + "   at System.Diagnostics.ActivityCreationOptions`1.get_TraceId()"
    + "\n" + "   at OpenTelemetry.Trace.TracerProviderSdk.ComputeActivitySamplingResult(ActivityCreationOptions`1& options, Sampler sampler)"
    + "\n" + "   at OpenTelemetry.Trace.TracerProviderSdk.<>c__DisplayClass8_0.<.ctor>b__4(ActivityCreationOptions`1& options)"
    + "\n" + "   at System.Diagnostics.ActivitySource.<>c.<CreateActivity>b__18_1(ActivityListener listener, ActivityCreationOptions`1& data, ActivitySamplingResult& result, ActivityCreationOptions`1& unused)"
    + "\n" + "   at System.Diagnostics.SynchronizedList`1.EnumWithFunc[TParent](Function`2 func, ActivityCreationOptions`1& data, ActivitySamplingResult& samplingResult, ActivityCreationOptions`1& dataWithContext)"
    + "\n" + "   at System.Diagnostics.ActivitySource.CreateActivity(String name, ActivityKind kind, ActivityContext context, String parentId, IEnumerable`1 tags, IEnumerable`1 links, DateTimeOffset startTime, Boolean startIt, ActivityIdFormat idFormat)"
    + "\n" + "   at System.Diagnostics.ActivitySource.StartActivity(String name, ActivityKind kind)"
    + "\n" + "   at NServiceBus.Extensions.Diagnostics.OutgoingLogicalMessageDiagnostics.StartActivity()"
    + "\n" + "   at NServiceBus.Extensions.Diagnostics.OutgoingLogicalMessageDiagnostics.<Invoke>d__4.MoveNext()"
    + "\n" + "--- End of stack trace from previous location where exception was thrown ---"
    + "\n" + "   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)"
    + "\n" + "   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task)";
    
    @Test
    public void testSequoiaClientExceptionFilter() {
        String sourceField = "foo";
        Configuration config = new ConfigurationImpl(Collections.singletonMap("source", sourceField));
        Context context = new ContextImpl(null, null);
        SequoiaClientException filter = new SequoiaClientException("test-id", config, context);

        Event e = new org.logstash.Event();
        TestMatchListener matchListener = new TestMatchListener();
        e.setField(sourceField, body);
        Collection<Event> results = filter.filter(Collections.singletonList(e), matchListener);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(1, matchListener.getMatchCount());

        System.out.println(e.getField("exceptionMessages"));

        System.out.println(e.getField("exceptions"));
        Assert.assertEquals(1, ((Collection<String>)e.getField("exceptions")).size());
        
    }
}

class TestMatchListener implements FilterMatchListener {

    private AtomicInteger matchCount = new AtomicInteger(0);

    @Override
    public void filterMatched(Event event) {
        matchCount.incrementAndGet();
    }

    public int getMatchCount() {
        return matchCount.get();
    }
}