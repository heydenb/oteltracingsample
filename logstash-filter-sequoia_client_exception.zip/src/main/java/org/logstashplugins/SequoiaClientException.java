package org.logstashplugins;

import co.elastic.logstash.api.Configuration;
import co.elastic.logstash.api.Context;
import co.elastic.logstash.api.Event;
import co.elastic.logstash.api.Filter;
import co.elastic.logstash.api.FilterMatchListener;
import co.elastic.logstash.api.LogstashPlugin;
import co.elastic.logstash.api.PluginConfigSpec;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;

// class name must match plugin name
@LogstashPlugin(name = "sequoia_client_exception")
public class SequoiaClientException implements Filter {

    public static final PluginConfigSpec<String> SOURCE_CONFIG =
            PluginConfigSpec.stringSetting("source", "message");

    private String id;
    private String sourceField;

    public SequoiaClientException(String id, Configuration config, Context context) {
        // constructors should validate configuration options
        this.id = id;
        this.sourceField = config.get(SOURCE_CONFIG);
    }

    @Override
    public Collection<Event> filter(Collection<Event> events, FilterMatchListener matchListener) {
        for (Event e : events) {
            Object f = e.getField(sourceField);
            if (f instanceof String) {
                parseMessage((String)f, e);
                e.setField("stacktrace", "extracted");
                matchListener.filterMatched(e);
            }
        }
        return events;
    }

    private void parseMessage(String message, Event e){
        List<String> exceptions = new ArrayList<String>();
        List<String> exceptionMessages = new ArrayList<String>();

        StringTokenizer t = new StringTokenizer(message, "\n");
        while(t.hasMoreTokens()){
            String line = t.nextToken();
            if (line.startsWith("FeatureToggles") && t.hasMoreTokens()){
                //No more FeatureToggles, no added value
                //e.setField("FeatureToggles", t.nextToken());
            }
            else if (line.startsWith("MessageId:")){
                e.setField("MessageId", line.substring("MessageId:".length()).trim());
            }
            else if (line.charAt(1)==')'){
                for (int i=1; i<=5; i++){
                    if (line.startsWith(i + ") ")){
                        exceptions.add(line.substring("x) ".length()).trim());
                        if (t.hasMoreTokens() && (line = t.nextToken()).startsWith("Message:")){
                            exceptionMessages.add(line.substring("Message:".length()).trim());
                            
                        }
                    }
                }
            }
            
            /* No more stacktrace. No added value
            else if (line.startsWith("StackTrace")){
                StringBuilder sb = new StringBuilder(line);
                while(t.hasMoreTokens()){
                    sb.append(t.nextToken());
                    sb.append("\n");
                }
                e.setField("StackTrace", sb.toString());
            }*/
        }
        e.setField("exceptions", exceptions);
        e.setField("exceptionMessages", exceptionMessages);
    }

    @Override
    public Collection<PluginConfigSpec<?>> configSchema() {
        // should return a list of all configuration options for this plugin
        return Collections.singletonList(SOURCE_CONFIG);
    }

    @Override
    public String getId() {
        return this.id;
    }
}
